package Ver_dat_kundp;


import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.*;


import Ver_dialog.Ver_kundenanzeige;

/*
 *  Aufruf aus ver_Dialog
 *  Sortierung ver_kundstamm  nach Name
 *  Nächstes Programm  ver_kundenanzeige
 *  Ber_Kundanzeige mit Parameter ArrayList liste Boolean auswb= false 
 *   */



public class Ver_anz_auswahls implements Interface.DB_zugriff{
	 

	ArrayList<String> liste = new ArrayList<String>(); 
	Boolean auswb;
	 public Ver_anz_auswahls(Boolean ausw){
		 auswb=ausw;
		 Connection conn = null; 
		 try {
             System.out.println("* Treiber laden");
             
         } catch (Exception e) {
             System.err.println("Treiber kann nicht geladen werden!!");
             e.printStackTrace();
         }
		         
		        try { 
		        	 System.out.println("* Verbindung aufbauen");
		    	    String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
		    	    conn =  (Connection) DriverManager.getConnection(url, user, password);
		    	    // ***** Verbindung
		    	 
		            Statement stmt = (Statement) conn.createStatement(); 

		         
			    String sqlCommand = "SELECT kun.verk_kundnr, kun.verk_name "
			    	    + "FROM ver_kundstamm kun "
			    	    + " ORDER BY kun.verk_name";
			      System.out.println(sqlCommand);
			    ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			    
			    
			  
			    while (rs.next()) { 
			    liste.add( rs.getString(1));  //Kundennummer
				liste.add(rs.getString(2));      //Name
				
				
				
		        
			    }
			     System.out.println(liste);
			     
		       
		       
		        
		       
			    
			    
			     
	    	    conn.close(); 
	            } 
	            catch (SQLException sqle) { 
	                System.out.println("SQLException: " + sqle.getMessage()); 
	                System.out.println("SQLState: " + sqle.getSQLState()); 
	                System.out.println("VendorError: " + sqle.getErrorCode()); 
	                sqle.printStackTrace(); 
	            } 
		            if(auswb) {  // true dann Auswahl Update
		            	
		            	 Ver_kundenanzeige vka = new Ver_kundenanzeige(liste,auswb);
		            }
		            //Hier  Aufruf Kundenanzeige
		            else {  //auswb=false
		              Ver_kundenanzeige vka = new Ver_kundenanzeige(liste,auswb);
		            }
	}
	

/*	public static void main(String[] args) {
		new Ver_anz_auswahls();
    
	}*/

}
