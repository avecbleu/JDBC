package Ver_dat_kundp;

/* Aufruf aus Programm  Ver_Kund_adr_ausw mit Parameter  Kundenummer name  usw.
 *  Grafische Aufbereitung der übergebenen Daten  
 */

import static java.awt.GridBagConstraints.*;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ver_kund_anz extends JFrame {
	private int top, left, bottom, right;
    private final Insets insetsTop = new Insets(top = 5, left = 2, bottom = 15, right = 0);
  String gebdats,jj,mm, tt;    
    // aus  Ver_Kund_adr_ausw
	public Ver_kund_anz(String kundennummer, String name, String vorname, String gebdat,
			            String strasse, String hausnr, String plz, String ort) {
		 
	
		
		this.setTitle("Anzeigen Kundenstamm");
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        GridBagLayout gbLayout = new GridBagLayout();
	        GridBagConstraints gbConstraints = new GridBagConstraints();
	        setLayout(gbLayout);
	        //Anzeig Überschrift
	        gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        
	        //********Anzeigen Label Name
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty = 0;
	        gbConstraints.anchor = PAGE_START;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 0;
	       gbConstraints.insets = insetsTop;	       
	        JLabel texthaed = new JLabel("Ausgabe Kundenstamm" );
	        add(texthaed,gbConstraints);
	        //Kundnnummer 
	        gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty =0; 
	       
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 1;
	       gbConstraints.insets = insetsTop;	       
	        JLabel textkdnr = new JLabel("Kundennummer:" );
	        add(textkdnr,gbConstraints);
	        //*****Anzeigen Kundennummer aus Datenbank
	        gbConstraints.weightx = 1;
	        //gbConstraints.weighty = 1;
	        gbConstraints.gridx = 1;
	        gbConstraints.gridy = 1;
	        JLabel lkdnr = new JLabel();
	        lkdnr.setText(kundennummer);      
	        add(lkdnr,gbConstraints);
	        
	      gbConstraints.fill = GridBagConstraints.HORIZONTAL;
	        gbConstraints.weightx = 0;
	        gbConstraints.weighty =0; 
	       // gbConstraints.anchor = PAGE_START;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 1;
	       gbConstraints.insets = insetsTop;	       
	        JLabel textName = new JLabel("Name:" );
	        add(textName,gbConstraints);
	        //*****Anzeigen Name aus Datenbank
	        gbConstraints.weightx = 1;
	        //gbConstraints.weighty = 1;
	        gbConstraints.gridx = 3;
	        gbConstraints.gridy = 1;
	        JLabel lName = new JLabel();
	        lName.setText(name);      
	        add(lName,gbConstraints);
	      //*****Anzeigen Label Vorname
	        gbConstraints.weightx = .5;
	        //gbConstraints.weighty = 0.5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 2;
	        JLabel textvName = new JLabel("Vorname:" );
	        add(textvName,gbConstraints);
	        //**********Anzeigen Vorname aus Datenbank
	        gbConstraints.weightx = 1;
	       // gbConstraints.weighty = 1;
	        gbConstraints.gridx = 1;	        
	        JLabel lvName = new JLabel();
	        lvName.setText(vorname);      
	        add(lvName,gbConstraints);
	     //*****Anzeigen Label Gebursdatum
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 2;
	        JLabel textvgebd = new JLabel("Geb_Dat:" );
	        add(textvgebd,gbConstraints);
	       //**********Anzeigen Geb_datum aus Datenbank
	        gbConstraints.weightx = 1;
	       // gbConstraints.weighty = 1;
	        gbConstraints.gridx = 3;	        
	        JLabel lgebdat = new JLabel();
	        lgebdat.setText(gebdat);      
	        add(lgebdat,gbConstraints);
	         //*******Anzeigen Label Strasse
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 3;
	        JLabel textstr = new JLabel("Straße:" );
	        add(textstr,gbConstraints);
	      //*******Anzeigen Label StraßeDatenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 1;
	        JLabel lstrasse = new JLabel();
	        lstrasse.setText(strasse);
	        add(lstrasse,gbConstraints);
	      //*******Anzeigen Label Hausnummer
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 3;
	        JLabel texthsr = new JLabel("Hausnummer:" );
	        add(texthsr,gbConstraints);
	      //*******Anzeigen Label Hausnummer Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 3;
	        JLabel lhsr = new JLabel();
	        lhsr.setText(hausnr);
	        add(lhsr,gbConstraints);
	        //*******Anzeigen Label Postleitzahl
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 0;
	        gbConstraints.gridy = 4;
	        JLabel textplz = new JLabel("Postleitzahl:" );
	        add(textplz,gbConstraints);
	      //*******Anzeigen Label Postleitzahl Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 1;
	        JLabel lplz = new JLabel();
	        lplz.setText(plz);
	        add(lplz,gbConstraints);
	        //*******Anzeigen Label Ort
	        gbConstraints.weightx = .5;
	        gbConstraints.gridx = 2;
	        gbConstraints.gridy = 4;
	        JLabel textort = new JLabel("Ort:" );
	        add(textort,gbConstraints);
	      //*******Anzeigen Label Ort Datenbank
	        gbConstraints.weightx = 1;
	        gbConstraints.gridx = 3;
	        JLabel lort = new JLabel();
	        lort.setText(ort);
	        add(lort,gbConstraints);
	        setSize(400, 300);
	        //pack();
	        setVisible(true);
	}

	

}
