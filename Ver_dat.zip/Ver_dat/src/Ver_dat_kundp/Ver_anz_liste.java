package Ver_dat_kundp;


import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;





public class Ver_anz_liste {
	 // Diese Eintraege werden zum 
    // Verbindungsaufbau benoetigt. 
    final String hostname = "localhost"; 
    final String port = "3306"; 
    final String dbname = "ver_dat"; 
    final String user = "root"; 
    final String password = ""; 

    
	
	 public Ver_anz_liste(){
		 Connection conn = null; 
		 try {
             System.out.println("* Treiber laden");
             // Class.forName("org.gjt.mm.mysql.Driver").newInstance();
             //Class.forName("com.mysql.jdbc.Driver");  //neu
           //  Class.forName("com.mysql.cj.jdbc.Driver");  //neu
         } catch (Exception e) {
             System.err.println("Treiber kann nicht geladen werden!!");
             e.printStackTrace();
         }
		         
		        try { 
		        	 System.out.println("* Verbindung aufbauen");
		    	    String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
		    	    conn =  (Connection) DriverManager.getConnection(url, user, password);
		    	    // ***** Verbindung
		    	 
		            Statement stmt = (Statement) conn.createStatement(); 

		         
			    String sqlCommand = 
			    		"SELECT kun.verk_kundnr, kun.verk_name, kun.verk_Vorname, adr.V_Strasse,"
			    	    +"adr.V_Hausnr,adr.V_PLZ,adr.V_Ort "
			    	    + "FROM ver_kundstamm AS kun JOIN ver_adresse AS adr ON "
			    	    + "kun.verk_kundnr = adr.V_Kundnr"
			    	    + " ORDER BY kun.verk_name";
			      System.out.println(sqlCommand);
			    ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			    
			    //***Ausgabe
			    String zeile="";
			    while (rs.next()) { 
			    String  kundennummer  = rs.getString(1); 
				String name    = rs.getString(2);
				String vorname = rs.getString(3);
				String strasse   = rs.getString(4);
				String hausnr = rs.getString(5);
				String plz   = rs.getString(6);
				String ort = rs.getString(7);
				
				zeile  += kundennummer+"\t"+name+", "+"\t"+vorname+"\t"+strasse+", "+hausnr+", "
						+"\t" + plz+"\t"+ort+"\n";
				System.out.println(zeile);
		        
			    }
			         
			      //Macht das Frame
		        JFrame frm = new JFrame("Listenanzeige Kunden ");
		        frm.setLayout(null);
		        frm.setBounds(10, 10, 500, 400);
		        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		        
		        Font font = new Font("Verdana", Font.ITALIC, 14);
		       
		       // JLabel lblTitel = new JLabel("Kundenanzeige mit Adresse ", SwingConstants.CENTER);
		        JLabel lblTitel = new JLabel("Kundenanzeige mit Adresse ");
		        lblTitel.setFont(font);
		        lblTitel.setBounds(0, 0, 380, 25);
		        frm.add(lblTitel);
		        
		        JTextArea ausgabe = new JTextArea(zeile);
		        ausgabe.setEditable(false);
		       
		        JScrollPane scrollPane = new JScrollPane(ausgabe);
		          scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		          scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		          scrollPane.setBounds(10, 30, 460, 120);	
		        
		        frm.add(scrollPane);
		        frm.setLocationRelativeTo(null);
		        frm.setVisible(true);
			    
			    
			     
	    	    conn.close(); 
	            } 
	            catch (SQLException sqle) { 
	                System.out.println("SQLException: " + sqle.getMessage()); 
	                System.out.println("SQLState: " + sqle.getSQLState()); 
	                System.out.println("VendorError: " + sqle.getErrorCode()); 
	                sqle.printStackTrace(); 
	            } 
		
	}
	

	/*public static void main(String[] args) {
		new Ver_anz_liste();
    
	}*/

}
