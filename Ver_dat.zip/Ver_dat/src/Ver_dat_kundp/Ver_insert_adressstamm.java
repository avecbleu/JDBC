package Ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Interface.DB_zugriff;

// Adresse ( ver_adresse) updaten von verkunde_update

public class Ver_insert_adressstamm implements Interface.DB_zugriff {
String strasse,hausnr, plz, ort;

	public Ver_insert_adressstamm(String strasses, String hausnrs, 
			                String plzs, String ortss, String lkzs, String kundenr) {

		

		Connection conn = null;

		try {
			System.out.println("* Treiber laden");
			
		} catch (Exception e) {
			System.err.println("Treiber kann nicht geladen werden!!");
			e.printStackTrace();
		}

		try {
			System.out.println("* Verbindung aufbauen");
			String url = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
			conn = DriverManager.getConnection(url, user, password);
			// ***** Verbindung
			System.out.println("* Statement beginnen");
			Statement stmt = (Statement) conn.createStatement();
			// *************hier SQL:Statments
			System.out.println("* Einfügen  beginnen");

			
			System.out.println(kundenr + "  " + strasses);
			
			String sqlCommand = "Insert INTO ver_adresse (V_Strasse, V_Hausnr,"
					+ "V_PLZ, V_Ort,V_LKZ,V_Kundnr,V_timestamp)" 
					+ "VALUES("+ "'" + strasses + "'" +"," + "'" 
					+ hausnrs + "'" + ","	+ "'" + plzs 
					+ "'" + "," + "'" + ortss   + "'" + ","
					+ "'" + lkzs + "'" + "," + "'" + kundenr + "'" + ","
					+"NOW()" + ")";
			
			System.out.println(sqlCommand);
			((java.sql.Statement) stmt).executeUpdate(sqlCommand); // da nur geschrieben wird
											// executeUpdate

			// **beenden Eingabe
			System.out.println("* Statement beenden");
			 stmt.close();

			System.out.println("* Statement beginnen");
			stmt = (Statement) conn.createStatement();

			// ***Ausgabe
			System.out.println("* Ergebnisse anzeigen");
			System.out.println("* Abfrage beginnen");
			sqlCommand = "SELECT V_Strasse, V_Hausnr, V_PLZ, V_Ort FROM ver_adresse";
			ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			// ***Ausgabe
			System.out.println("* Ergebnisse anzeigen");
			while (rs.next()) {

				strasse = rs.getString(1);
				hausnr = rs.getString(2);
				plz = rs.getString(3);
				ort = rs.getString(4);
				// double gehalt = rs.getDouble(3); hier weiter
				System.out.println(strasse + " " + hausnr + " " + " " + plz + " " + ort);

			}

			System.out.println("* Statement beenden");
			 stmt.close();
			System.out.println("* Datenbank-Verbindung beenden");
			conn.close();
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
			System.out.println("SQLState: " + sqle.getSQLState());
			System.out.println("VendorError: " + sqle.getErrorCode());
			sqle.printStackTrace();
		}

		// Ver_kund_anz vka = new Ver_kund_anz(kundennummer,name,vorname,g_dat);

	}// Konstruktor ende

}