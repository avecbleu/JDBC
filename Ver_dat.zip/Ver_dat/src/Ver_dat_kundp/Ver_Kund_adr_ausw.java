package Ver_dat_kundp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Interface.DB_zugriff;
import Ver_dialog.Ver_kunde_update;

/*Aufruf aus  Ver_kundenanzeige
 * Parameter Kundenummer Bollean Variable  updp
 * Datenbankzugriff auf Kundenstamm und Adresstamm 
 * mit der ausgewählten  Kundennummer
 */




public class Ver_Kund_adr_ausw implements Interface.DB_zugriff {
	
    String  kundennummer  ;
	String name    ;
	String vorname ;
	String gebdat ;
    String	 strasse ; 
    String	 hausnr ;
    String	 plz  ;
    String	 ort   ;

    Boolean updb2;
	
	 public Ver_Kund_adr_ausw(String kundenr, Boolean updb){
		 updb2=updb;
		 Connection conn = null; 
		 try { 
			    System.out.println("* Treiber laden"); 
		      	    //Class.forName("org.gjt.mm.mysql.Driver").newInstance(); 
		        } 
		        catch (Exception e) { 
		            System.err.println("Treiber kann nicht geladen werden!!"); 
		            e.printStackTrace();
	            } 
		         
		        try { 
		    	    System.out.println("* Verbindung aufbauen"); 
		    	    String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
		    	    conn = (Connection) DriverManager.getConnection(url, user, password); 
		    	    // ***** Verbindung
		    	    System.out.println("* Statement beginnen"); 
		            Statement stmt = (Statement) conn.createStatement(); 

		            System.out.println("* Abfrage beginnen"); 
			    String sqlCommand = 
			    		"SELECT  verk_kundnr, verk_name, verk_Vorname,verk_geburtstag, V_Strasse,"
			    		+"V_Hausnr,V_PLZ,V_Ort FROM ver_kundstamm"
			    	    + "	INNER JOIN ver_adresse ON ver_kundstamm.verk_kundnr = ver_adresse.V_Kundnr"
			    		+ " Where verk_kundnr LIKE '%"+kundenr+"'" ;
			    		
			    System.out.println(sqlCommand);
			    ResultSet rs = ((java.sql.Statement) stmt).executeQuery(sqlCommand);
			    
			    //***Ausgabe
			    System.out.println("* Ergebnisse anzeigen"); 
			    while (rs.next()) { 
				 
				  kundennummer  = rs.getString(1); 
				  name    = rs.getString(2);
				  vorname = rs.getString(3);
				  gebdat = rs.getString(4);
			    	 strasse  = rs.getString(5);
			    	 hausnr  = rs.getString(6);
			    	 plz  = rs.getString(7);
			    	 ort   = rs.getString(8);
				//double gehalt = rs.getDouble(3);  hier weiter
				System.out.println( kundennummer+" "+name+" "+" "+vorname +" "+ gebdat+" "+strasse+ " " +hausnr
						     +" "  + plz +" " +ort ); 
			    } 
			    System.out.println("* Datenbank-Verbindung beenden"); 
	    	    conn.close(); 
	    	    // Aufruf GUIAnzeige  
	    	    if (updb2) { //Update
	    	     Ver_kunde_update vku  = new Ver_kunde_update(kundennummer,name,vorname,gebdat,
	    	    				                     strasse,hausnr,plz,ort, sqlCommand);
	    	    }
	    	    else { //Aufruf Anzeige
	     	    	Ver_kund_anz vak  = new Ver_kund_anz(kundennummer,name,vorname,gebdat,
		                     strasse,hausnr,plz,ort);
	    	    }
	            } 
	            catch (SQLException sqle) { 
	                System.out.println("SQLException: " + sqle.getMessage()); 
	                System.out.println("SQLState: " + sqle.getSQLState()); 
	                System.out.println("VendorError: " + sqle.getErrorCode()); 
	                sqle.printStackTrace(); 
	            } 
		
	}
	



}
