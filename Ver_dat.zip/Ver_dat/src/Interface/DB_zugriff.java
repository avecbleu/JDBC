package Interface;



public interface DB_zugriff  { 
	// Diese Eintraege werden zum
			// Verbindungsaufbau benoetigt.
			final String hostname = "localhost";
			final String port = "3306";
			final String dbname = "ver_dat";
			final String user = "root";
			final String password = "q59znpcfrk";

			
}


