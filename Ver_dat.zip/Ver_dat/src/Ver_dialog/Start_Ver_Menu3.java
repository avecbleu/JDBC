package Ver_dialog;

import java.awt.BorderLayout;
import java.io.FileNotFoundException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Ver_dat_kundp.Ver_anz_auswahls;
import Ver_dat_kundp.Ver_anz_liste;



public class Start_Ver_Menu3 extends JFrame {
	 // Menüleiste 
	
    JMenuBar menuBar;
 
    // Menü "Datei"
    JMenu fileMenu;
    JMenu  fileueber;
 
   
    JMenuItem openItem4;
    JMenuItem openItem3; 
    JMenuItem openItem;  //Änderung
  
    JMenuItem closeItem;
    Boolean auswb= false; // Wenn update ausgewählt wird
    public Start_Ver_Menu3() {
        this.setTitle("JMenu mit ActionListener Test2");
        this.setSize(400, 300);
 
        // Menüleiste wird erzeugt
        menuBar = new JMenuBar();
 
        // Menü "Datei" wird erzeugt
        fileMenu = new JMenu("Kundenstamm");
        
      
       openItem4 = new JMenuItem("Anzeige Kunden mit Adresse");
       openItem3 = new JMenuItem("Anzeige Einzelkunden");  //Änderung
       openItem = new JMenuItem("Eingabe Kunden");  //Änderung
 
      
        fileMenu.add(openItem4);  // Anzeige Kunde mit Adresse
        fileMenu.add(openItem3); 
        fileMenu.add(openItem);  // Eingabe Einzelkunde  //Änderung
    
        //Datei-Menü wird der Menüleiste hinzugefügt
        menuBar.add(fileMenu);
        //menuBar.add(fileueber);
 
        //Menüleiste wird dem JFrame hinzugefügt
        this.add(menuBar, BorderLayout.NORTH);
        
      //************ActionListener für openItem Eingabe Kunden
        openItem.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Eingabe Kundendaten 
           
                  
            		
                 Ver_kunde3 vk3 = new Ver_kunde3();
               
            }
        });
 
        
        //************ActionListener für openItem4 Anzeige Kunden
        openItem4.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Eingabe Kundendaten 
           
                  
            		Ver_anz_liste val =new Ver_anz_liste();
            
               
            }
        });
        
        //************ActionListener für openItem3 Eingabe Kunden
        openItem3.addActionListener(new java.awt.event.ActionListener() {
            // Beim Drücken des Menüpunktes wird actionPerformed aufgerufen
            public void actionPerformed(java.awt.event.ActionEvent e3) {
                // Eingabe Kundendaten 
           
                  auswb=false;
            		
                      Ver_anz_auswahls verau = new Ver_anz_auswahls(auswb); // Auswahl Kunden
               
            }
        });
       
        
        setVisible(true);
    }
    public static void main(String[] args) {
		Start_Ver_Menu3 vmn = new Start_Ver_Menu3();

	}
    
}
